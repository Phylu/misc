<?php
/**
 * TUMonline --> Google Calendar Converter
 * Copyright 2011 by Janosch Maier
 * Licensed under the EUPL V.1.1
**/
	include("functions.php");
?>
<html>
	<head>
		<title>TUMonline &rarr; Google Calendar Converter</title>
		<link rel="stylesheet" href="style.css" type="text/css" media="all">
	</head>

	<body>
		<h1>TUMonline &rarr; Google Calendar Converter</h2>
		<p>Converts your TUMonline calendar url to a format that is usable by Google Calendar</p>
		<?php
			if (isset($_POST['url']) AND $_POST['url'] != "") {
				parse_calendar_url($_POST['url']);
			} else {
				print_form();
			}
		?>
	<p>&copy; 2011 Janosch Maier</p>
	</body>
</html>
